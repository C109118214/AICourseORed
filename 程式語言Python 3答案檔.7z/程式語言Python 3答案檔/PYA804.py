st = input()

str1 = st.upper()
print(str1)

str2 = st.title()
print(str2)
h = eval(input())
w = eval(input())
peri = (h+w)*2
area = h*w

print("Height = %.2f" % h)
print("Width = %.2f" % w)
print("Perimeter = %.2f" % peri)
print("Area = %.2f" % area)
import math

s = eval(input())

area = (5*math.pow(s, 2)) / (4*math.tan(math.pi/5))
print("Area = %.4f" % area)

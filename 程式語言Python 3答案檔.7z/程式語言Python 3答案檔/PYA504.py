def compute(a, b):
    return a**b

a = eval(input())
b = eval(input())

print(compute(a, b))
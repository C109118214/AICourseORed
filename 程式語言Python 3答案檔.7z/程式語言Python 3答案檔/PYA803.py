s = input()
s_list = s.split(' ')

print(' '.join(s_list[-3:]))
def compute():
    stu_dept = input()
    stu_id = input()
    stu_name = input()
    
    print("Department:", stu_dept)
    print("Student ID:", stu_id)
    print("Name:", stu_name)

compute()
def compute(a, b):
    return a * b

num1 = eval(input())
num2 = eval(input())

print(compute(num1, num2))
a = int(input())

if a%2 == 0:
    print("%d is an even number." % a)
else:
    print("%d is not an even number." % a)

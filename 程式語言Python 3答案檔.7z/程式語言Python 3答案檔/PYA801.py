string = input()

for i in range(len(string)):
    print("Index of '%c': %d" % (string[i], i))